function P = polyhedron(C)
%POLYHEDRON (Overloaded)

P = polyhedron(lmi(C));