% estimate the local frame of reference at this point
% method of Gabriel Taubin

function [H, K, V,D] = computeDarbouxFrame(dx, dy, xs, ys, zs)

    % (1). compute normal of the point
    tanX = [1, 0, dx];
    tanY = [0, 1, dy];
    Norm = cross(tanX, tanY)';
    Norm = Norm/norm(Norm);


    % (2). estimate a matrix M
    numPoints = length(xs);
    M = zeros(3,3);
    
    % compute weights for each point (reverse to geometric distance)
    dist = sqrt(xs.^2 + ys.^2 + zs.^2);  
    sd = sum(dist);
    w = dist/sd;

    for ii = 2:numPoints

        vj = [0,0,0]';
        vi = [xs(ii), ys(ii), zs(ii)]';
        vect = (vi - vj);
        if norm(vect) < 1
            continue;
        end

        Tij = (eye(3) - Norm*Norm')*vect;
        Tij = Tij / norm(Tij);

        % estimate directional curvature
        kij = 2 * Norm' * vect / (norm(vect)^2); 

        MTemp = w(ii) * kij * Tij * Tij';

        M = M + MTemp;
    end

    [V,D] = eig(M);
%     values = abs(diag(D));
%     [valuesSort, idx] = sort(values, 'ascend');
%     D = diag(valuesSort);
%     V = V(:, idx);
    
    H = (D(2,2) + D(3,3) / 2);
    K = 1;
end

