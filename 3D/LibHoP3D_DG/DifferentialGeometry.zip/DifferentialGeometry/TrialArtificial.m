% this is to try different differential geometry algorthms for the
% artificial data


elementType = 2;
elementRadius = 10;
is2D = false;

imSize = 300;
I = zeros(imSize, imSize);

methodId = 1; 

%% here we create a primitive
primType = 3; % cylinder
zeroThresh = 10^(-3);
slant = pi/6;
elevation = 1;

if primType == 1
    r = 70;
    h = 200;
    
    cylCentre = [150, 150, 0];
    cylinderStartX = cylCentre(1) - r;
    cylinderEndX = cylCentre(1) + r;
    cylinderStartY = cylCentre(2) - h/2;
    cylinderEndY = cylCentre(2) + h/2;
    
    for y = cylinderStartY:cylinderEndY
        for x = cylinderStartX:cylinderEndX
            
            xCyl = x - cylCentre(1);
            z = sqrt(r^2 - xCyl^2);
            
            I(y,x) = z;
            
        end
    end
    
elseif primType == 2 % sphere
    r = 100;
    centre = [150, 150, 0];
    startX = centre(1) - r;
    endX = centre(1) + r;
    startY = centre(2) - r;
    endY = centre(2) + r;
    
    for y = startY:endY
        for x = startX:endX
            
            % check if the point belongs to the sphere
            if (x - centre(1))^2 + (y - centre(2))^2 < r^2
                z = sqrt(r^2 - (x - centre(1))^2 - (y - centre(2))^2) + centre(3);
                I(y,x) = z;
            end
        end
    end
    
elseif primType == 3 % Planar
    
    r = 70;
    h = 200;
    z0 = 10;
    
    cylCentre = [150, 150, 0];
    cylinderStartX = cylCentre(1) - r;
    cylinderEndX = cylCentre(1) + r;
    cylinderStartY = cylCentre(2) - h/2;
    cylinderEndY = cylCentre(2) + h/2;
    
    for y = cylinderStartY:cylinderEndY
        for x = cylinderStartX:cylinderEndX
            
            
            z = z0 + x * 0.5;
            
            I(y,x) = z;
            
        end
    end
    
end

% I = imrotate(I,-30);
slant = 0.1:0.1:30;
Iadd = repmat(slant, [imSize,1]);
I = I +Iadd;
imtool(Iadd, [1,200]);


%% here we compute all the transformations



%% compute derivatives (if it is required)

gf = fspecial('gaussian', 5 ,1.0);
Ig = imfilter(I, gf);
dx = 0.5*[-1 0 1];
dy = dx';

Ix = imfilter(Ig, dx);
Iy = imfilter(Ig, dy);


%% compute all parameters from the range image

radRC = 10;
minDepth = 1;
[r,c] = size(I);

halfImage(1) = floor(r/2)+1;
halfImage(2) = floor(c/2)+1;

%% visualize the results

% visualization parameters for the local frame of reference
vecLen = 25;
vectColors = [1,0,0; 0,1,0; 0,0,1]; 


surf(I, 'FaceColor',[0.3, 0.3 0.3], 'FaceAlpha', 0.4, 'EdgeColor', 'none', 'FaceLighting', 'phong');
camlight left
axis equal;
hold on


for x = 120:20:200;
    y = 150;

        curDepth = I(y,x);
        [indsXOut, indsYOut, depths] = computeNeighbors(I, x, y, elementRadius, is2D, minDepth);
%       % test for a neihbourhood found 
%         scatter3(indsXOut, indsYOut, depths);


%         % now we convert these coordinates to the local frame of
%         % reference (centered at the point [j,i,curDepth])
        xs = indsXOut - x;
        ys = indsYOut - y;
        zs = depths - I(y,x);
% 
        if methodId == 1  % paraboloid fitting
            
            [H, K, QF1, QF2, S, V, D] = paraboloidFitting(xs, ys, zs);
        
        elseif methodId == 2 % method of Gabriel Taubin (modified)
            
             [H1, K1, V, D] = computeDarbouxFrame(Ix(y,x), Iy(y,x), xs, ys, zs);
            
        end
%         
% 
        % plot the eigenvectors in 3D
        for ii = 1:3
            curVect = V(:, ii);
            curColor = vectColors(ii, :);
            XX = [x, x + vecLen * curVect(1)];
            YY = [y, y + vecLen * curVect(2)];
            ZZ = [curDepth, curDepth + vecLen * curVect(3)];

            plot3(XX, YY, ZZ, 'Color', curColor);
            hold on
            
        end
        
        
        


%     end 
end
    
a = 2;
clear all



    


    
    
    
    
    
    
    
  


    